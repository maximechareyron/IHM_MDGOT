﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IHM_MDGOT.Modeles {
    public class HouseModel {
        public string _nom;
        public string Nom {
            get {
                return _nom;
            }
            set {
                _nom = value;
            }
        }
        private string _blason;
        public string Blason
        {
            get
            {
                return "/Métier_MDGOT;component/ImagesHouses/" + _blason.ToLower() + ".jpg";
            }
            set { }
        }

        public override string ToString() {
        return Nom;
        }

    }
}
