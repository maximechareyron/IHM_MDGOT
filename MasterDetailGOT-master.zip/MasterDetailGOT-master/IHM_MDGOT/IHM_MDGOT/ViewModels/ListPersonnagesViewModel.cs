﻿using IHM_MDGOT.Events;
using IHM_MDGOT.Factories;
using IHM_MDGOT.Modeles;
using Library;
using Métier_MDGOT;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IHM_MDGOT.ViewModels {
	public class ListPersonnagesViewModel : NotifyPropertyChangedBase {
		public DelegateCommand AddCommand { get; set; }
		public DelegateCommand EditCommand { get; set; }
		public DelegateCommand DeleteCommand{ get; set; }

		private PersonnageModel _personnage;
		private ObservableCollection<PersonnageModel> _listePersonnages;

        private AddView _fenetreAjoutPerso;
        private EditView _fenetreEditionPerso;


		public PersonnageModel Personnage {
			get {
				return _personnage;
			}
			set {
				_personnage = value;
				NotifyPropertyChanged("Personnage");
				NotifyPropertyChanged("ListePersonnage");
				EditCommand.RaiseCanExecuteChanged();
				DeleteCommand.RaiseCanExecuteChanged();
            }
		}

		public ObservableCollection<PersonnageModel> ListePersonnage {
			get {
				return _listePersonnages;
			}
			set {
				_listePersonnages = value;
			}
		}

		public ListPersonnagesViewModel() {
			ListePersonnage = PersonnageFactory.AllPersonnageEntitieToPersonnageModele(PersonnageDAO.GetAllPersonnage());

			AddCommand = new DelegateCommand(OnAddCommand, CanExecuteAdd);
			EditCommand = new DelegateCommand(OnEditCommand, CanEditCommand);
			DeleteCommand = new DelegateCommand(OnDeleteCommand, CanDeleteCommand);
		}

        private void CloseAddView(object sender, EventArgs e) {
            _fenetreAjoutPerso.Close();
            ButtonPressedEvent.GetEvent().Handler -= CloseAddView;
        }

        private void CloseEditView(object sender, EventArgs e) {
            _fenetreEditionPerso.Close();
            ButtonPressedEvent.GetEvent().Handler -= CloseEditView;
        }

		private void OnAddCommand(object o) {
            ButtonPressedEvent.GetEvent().Handler += CloseAddView;

			_fenetreAjoutPerso = new AddView();
			_fenetreAjoutPerso.Name = "Ajout";
			_fenetreAjoutPerso.ShowDialog(); //actif tant que la fenetre est ouverte.

            if (_fenetreAjoutPerso.ViewModel.IsSaisieValid) {
                ListePersonnage.Add(_fenetreAjoutPerso.ViewModel.Personnage);
                NotifyPropertyChanged("ListePersonnage");
            }
		}

		private void OnEditCommand(object o) {
            ButtonPressedEvent.GetEvent().Handler += CloseEditView;

            _fenetreEditionPerso= new EditView(Personnage);
            _fenetreEditionPerso.Name = "Modifier";
			_fenetreEditionPerso.ShowDialog();

            if (_fenetreEditionPerso.ViewModel.IsSaisieValid) {
                ListePersonnage.Remove(Personnage);
                ListePersonnage.Add(_fenetreEditionPerso.ViewModel.Personnage);
                NotifyPropertyChanged("ListePersonnage");
            }
		}

		private void OnDeleteCommand(object o) {
			ListePersonnage.Remove(Personnage);
			NotifyPropertyChanged("ListePersonnage");
		}

		private bool CanExecuteAdd(object o) {
			return true;
		}

		private bool CanDeleteCommand(object o) {
			return Personnage != null;
		}

		private bool CanEditCommand(Object o) {
			return Personnage != null;
		}

	}
}
