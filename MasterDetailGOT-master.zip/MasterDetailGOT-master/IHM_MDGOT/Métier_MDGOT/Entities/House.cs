﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Métier_MDGOT {
	public enum House {
        noHouse = 0,
        Arryn = 1,
        Baratheon = 2,
        Clegane = 3,
        GreyJoy = 4,
        Lannister = 5,
        Mormont = 6,
        Stark = 7,
        Targaryen = 8,
        Tully = 9,
        Tyrell = 10
	}
}
